import Users.Person.Manager;
import Users.Person.User;

import java.util.Scanner;

public class Main {
    //нужно сделать что бы юзер мог положить деньги на депозит
    //сделать что бы деньги росли через определённое время
    //что бы человек мог снять деньги
    //что бы менеджер мог ответить на вопросы
    //что бы при регистрации заявка уходит директору для подтверждния
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Manager manager = new Manager();
        User user = new User();
        boolean flag = true;
        while (flag) {
            System.out.println("Who are you? (Manager/User)");
            String who = in.next();
            if (who.equals("Manager")) {
                flag = false;
                manager.application(true);
            } else if (who.equals("User")) {
                flag = false;
                user.application(false);

            } else {
                System.out.println("You made the wrong choice");
            }
        }

    }
}
