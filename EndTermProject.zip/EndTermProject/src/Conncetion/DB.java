package Conncetion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DB {
    public static Connection getConnection() throws SQLException, ClassNotFoundException {
        String jdbcURL = "jdbc:postgresql://localhost:5432/EndTermProject";
        String username = "postgres";
        String password = "Rustam1almira";
        try {
            Connection con = DriverManager.getConnection(jdbcURL, username, password);
            return con;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }

    }
}

