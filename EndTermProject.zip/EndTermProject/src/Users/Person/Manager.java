package Users.Person;

import Users.Persons;

public class Manager extends Persons {
    private String role;

    public Manager() { }


    public Manager(String TIN, String first_name, String last_name, String login, String password, String role) {
        super(TIN, first_name, last_name, login, password);
        this.role = role;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

}
