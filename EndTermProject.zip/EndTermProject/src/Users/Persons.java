package Users;

import Users.Work.WorkManager.DBManager;
import Users.Work.WorkUser.DBUser;

import java.util.Scanner;

public class Persons{
    private String TIN;
    private String first_name;
    private String last_name;
    private String login;
    private String password;

    public Persons()  {}

    public Persons(String TIN, String first_name, String last_name, String login, String password) {
        this.TIN = TIN;
        this.first_name = first_name;
        this.last_name = last_name;
        this.login = login;
        this.password = password;
    }

    public String getTin() {
        return TIN;
    }

    public void setTin(String TIN) {
        this.TIN = TIN;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void application(boolean person) {
        Scanner in = new Scanner(System.in);
        DBUser u = new DBUser();
        DBManager m = new DBManager();
        boolean flag = false;
        while (!flag) {
            System.out.println("log in/sign up");

            String option = in.next();
            String option1 = in.next();
            if (option.equals("log") && option1.equals("in")) {
                if(person == true){
                    m.log_in();

                }else{
                    u.log_in();
                }
                flag = true;

            } else if (option.equals("sign") && option1.equals("up")) {
                if(person == true){
                   // m.newManager();
                    System.out.println("Only a bank employee can add a new manager");

                }else{
                    u.sign_up();
                }

                flag = true;

            } else {
                System.out.println("You made a mistake when entering");
                boolean flags = true;
                while(flags) {
                    System.out.println("Do you want to continue?(yes/no)");
                    String yesNo = in.next();
                    if (yesNo.equals("yes")) {
                        flag = true;
                        flags = false;
                        Persons persons = new Persons();
                        persons.application(person);
                    } else if (yesNo.equals("no")) {
                        flag = true;
                        flags = false;
                    }else{
                        System.out.println("You made a mistake when entering");
                    }
                }
            }
        }


    }


}
