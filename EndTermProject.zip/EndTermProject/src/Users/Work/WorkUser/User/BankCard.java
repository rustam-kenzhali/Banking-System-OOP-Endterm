package Users.Work.WorkUser.User;

import Conncetion.DB;

import java.sql.*;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class BankCard {
    Random random = new Random();
    Scanner in = new Scanner(System.in);
    //стоит пересмотреть возможно где то стоит использовать два иннер джоина
    public void  addCard(String tin) {
        //мы должны для начала проверить есть ли у человека карта или нет
        //так как у каждого жителя казахстана свой ИИН и нету схожих
        //мы проверяем только по ИИН
        //для начала нужно найти айди пользователя с таким ИИН

        /////////////////Нужно отпрвить данные в юзеркард!!!!!!!!!!!!!!!!!!!!

        Connection con = null;
        boolean flag = true;
        try{
            con = DB.getConnection();
            int user_idSQL = BankCard.finduserID(tin);

            String newsql = "select user_id from usercard";
            Statement st = con.createStatement();
            ResultSet results = st.executeQuery(newsql);
            while (results.next()){
                int user_iduserscard = results.getInt("user_id");
                if(user_idSQL == user_iduserscard){
                    //если правда значит у человека уже существует банковская карта
                    //каждый пользователь имеет право откыть только 1 карту как в каспи банке
                    flag = false;
                    System.out.println("You already have a card. Check it!");
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        if(flag == true) {
            String card_number = "";
            for (int i = 0; i < 16; i++) {
                card_number += String.valueOf(random.nextInt(9));
            }
            try {
                con = DB.getConnection();
                String sql = "INSERT INTO card (card_number) VALUES(?)";
                PreparedStatement addCard = con.prepareStatement(sql);
                addCard.setString(1, card_number);
                addCard.executeUpdate();

                int user_id = BankCard.finduserID(tin); //находим айди нынешнего пользователя

                String newsql = "select card_id, card_number from card"; //этот пидарас не находит айди
                Statement state = con.createStatement();   //Statement used for executing SQL queries
                ResultSet results = state.executeQuery(newsql); //The ResultSet class represents the resulting data set and provides the application with row-by-row access to query results.
                int card_id = 0;
                while(results.next()) {
                    String cardnumb = results.getString("card_number");
                    if(cardnumb.equals(card_number)){
                        card_id = results.getInt("card_id");
                    }

                }

                String UCsql = "INSERT INTO usercard (user_id, card_id) VALUES (?,?)";
                PreparedStatement preparedStatement = con.prepareStatement(UCsql);
                // Устаовка параметров
                preparedStatement.setInt(1, user_id); //в первый ?
                preparedStatement.setInt(2, card_id); // во второй ?
                preparedStatement.executeUpdate();

                // Выполнение запроса

                System.out.println("Your card was created");
                System.out.println("card number: " + card_number);


            } catch (SQLException throwables) {
                throwables.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
        }else{
        }

    }

    //стоит пересмотреть возможно где то стоит использовать два иннер джоина
    public void checkCard(){
        Connection con = null;
        try{
            con = DB.getConnection();
            String sql = "SELECT card_number, money from card";
            Statement st = con.createStatement();   //Statement used for executing SQL queries
            ResultSet result = st.executeQuery(sql); //The ResultSet class represents the resulting data set and provides the application with row-by-row access to query results.
            String  card_number = " ";
            int money  = 0;
            while(result.next()) {
                card_number = result.getString("card_number"); //бегаем по всему сталбцу, и обновляем данные, в итоге сохраниться самая последняя/максмильная
                money = result.getInt("money");
            }
            System.out.println("Your card number: " + card_number);
            System.out.println("The amount of money in your account: " + money);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    //стоит пересмотреть возможно где то стоит использовать два иннер джоина
    public void addMoney(String tin){
        Connection con = null;
        try {
            con = DB.getConnection();

            String newSQL = "SELECT * from usercard INNER JOIN users ON usercard.user_id = users.user_id WHERE users.tin = (?)";
            PreparedStatement  prS = con.prepareStatement(newSQL);
            prS.setString(1, tin);
            ResultSet result = prS.executeQuery();
            int card_id = -1;
            while (result.next()) { //выводим все полученные данные
                card_id = result.getInt("card_id");
            }

            if(card_id == -1){
                System.out.println("You haven't the card");
            }else {

                System.out.println("How much money you want to add?");
                int money = in.nextInt();
                String updateMoney = "UPDATE card SET money = ? WHERE card_id = ?;";
                PreparedStatement addM = con.prepareStatement(updateMoney);
                addM.setInt(1,money);
                addM.setInt(2, card_id);
                addM.executeUpdate();
                System.out.println("You added " + money + " money in your card");
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void transfer_of_money(String  tin){
        Connection con = null;
        try {
            con = DB.getConnection();
            String newsql = "SELECT * FROM card INNER JOIN usercard ON usercard.card_id = card.card_id INNER JOIN users ON UserCard.user_id = users.user_id WHERE Users.TIN = ?";
            PreparedStatement prS = con.prepareStatement(newsql);
            prS.setString(1,tin);
            prS.execute();
            ResultSet result = prS.executeQuery();
            result.next();
            int moneySQL = result.getInt("money");

            boolean to_repeat = true;
            while (to_repeat) {
                System.out.println("Your balance: " + moneySQL);
                System.out.println("We can only make a money transfer to a user of our bank");
                System.out.println("How much money you want to transfer?");
                int moneyForTransfer = in.nextInt();
                boolean stop = false;
                if (moneyForTransfer > moneySQL) {
                    boolean flag = true;
                    while (flag) {
                        System.out.println("You are missing " + (moneyForTransfer - moneySQL) + " for the transfer");
                        System.out.println("Do you want to repeat the operation with a different amount of money?(yes/no)");
                        String yesNo = in.next();
                        if (yesNo.equals("yes")) {
                            flag = false;
                        } else if (yesNo.equals("no")) {
                            flag = false;
                            stop = true;
                            to_repeat = false;
                        } else {
                            System.out.println("You input incorrect value");
                        }
                    }
                } else if (stop == false && moneyForTransfer <= moneySQL) {
                    System.out.println("Enter the phone number of the person you want to transfer money to");
                    String phone_number = in.next();

                    //отнимаем введённые деньги
                    String sql = "UPDATE card SET money = money - ?" +
                            "FROM usercard WHERE card_number = (SELECT card_number FROM  card " +
                            "INNER JOIN UserCard UC on Card.card_id = UC.card_id " +
                            "INNER JOIN Users U on U.user_id = UC.user_id WHERE U.tin = ?)";
                    PreparedStatement preparedStatement = con.prepareStatement(sql);
                    preparedStatement.setInt(1, moneyForTransfer);
                    preparedStatement.setString(2, tin);
                    preparedStatement.executeUpdate();

                    System.out.println("Your account balance: " + (moneySQL - moneyForTransfer));

                    //отправка денег на другой акк
                    sql = "UPDATE card SET money = money + ?" +
                            "FROM usercard WHERE card_number = (SELECT card_number FROM  card " +
                            "INNER JOIN UserCard UC on Card.card_id = UC.card_id " +
                            "INNER JOIN Users U on U.user_id = UC.user_id WHERE U.phone_number = ?)";
                    preparedStatement = con.prepareStatement(sql);
                    preparedStatement.setInt(1, moneyForTransfer);
                    preparedStatement.setString(2, phone_number);
                    preparedStatement.executeUpdate();

                    to_repeat = false;
                }
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }

    public void dropcard(String tin){
        System.out.println("WARNING! All the money in your account will be transferred to the bank");
        System.out.println("Are you sure you want to delete your card?(yes/no)");
        String yesNo = in.next();
        boolean flag = true;
        while (flag){
            if(yesNo.equals("yes")){
                Connection con = null;
                try {
                    flag = false;

                    con = DB.getConnection();

                    String sql = "SELECT card_number FROM card " +
                            "INNER JOIN usercard ON card.card_id = usercard.card_id " +
                            "INNER JOIN users ON usercard.user_id = users.user_id " +
                            "WHERE users.TIN = ?";
                    PreparedStatement prS = con.prepareStatement(sql);
                    prS.setString(1, tin);
                    prS.execute();
                    ResultSet resultSet = prS.executeQuery();
                    resultSet.next();
                    String card_number = resultSet.getString("card_number");

                    sql = "DELETE FROM usercard WHERE card_id = (SELECT card_id FROM usercard " +
                            "INNER JOIN users ON usercard.user_id = users.user_id " +
                            "WHERE users.TIN = ?)";
                    prS = con.prepareStatement(sql);
                    prS.setString(1, tin);
                    prS.executeUpdate();

                    sql = "DELETE FROM card WHERE card_number = ?";
                    prS = con.prepareStatement(sql);
                    prS.setString(1,card_number);
                    prS.executeUpdate();

                    System.out.println("Your card was deleted");
                } catch (SQLException throwables) {
                    throwables.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }


            }else if(yesNo.equals("no")){
                System.out.println("You made the right decision");
                flag = false;
            }else{

            }
        }
    }



    public static int finduserID(String tin){
        Connection con = null;
        int user_idSQL = 0;
        try {
            con = DB.getConnection();
            String newsql = "select user_id, tin from users";
            Statement st = con.createStatement();   //Statement used for executing SQL queries
            ResultSet results = st.executeQuery(newsql); //The ResultSet class represents the resulting data set and provides the application with row-by-row access to query results.
            while (results.next()) {
                String tinSQL = results.getString("tin"); //бегаем по всему сталбцу, и обновляем данные, в итоге сохраниться самая последняя/максмильная
                if (tin.equals(tinSQL)) {
                    user_idSQL = results.getInt("user_id");
                }
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        return user_idSQL;
    }
}
