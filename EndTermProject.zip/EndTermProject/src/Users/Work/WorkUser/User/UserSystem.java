package Users.Work.WorkUser.User;

import Users.Work.UserManager;

import java.util.Random;
import java.util.Scanner;

public class UserSystem {
    Scanner in = new Scanner(System.in);

    public void options(String tin) {
        BankCard bankcard = new BankCard();
        UserManager userManager = new UserManager();
        System.out.println('\n' + "Select an option");
        System.out.println("1)Open a bank card");
        System.out.println("2)Find out the bank number");
        System.out.println("3)Add funds to card number");
        System.out.println("4)Transfer money");
        System.out.println("5)Drop card");
        System.out.println("6)Write the question to manager");
        System.out.println("0)Exit");
        boolean f = false;

        int option = 111;
        while (option > 0) {
            if(f == true){
                System.out.println();
                System.out.println("Select an option");
                System.out.println("1)Open a bank card");
                System.out.println("2)Find out the bank number");
                System.out.println("3)Add funds to card number");
                System.out.println("4)Transfer money");
                System.out.println("5)Drop card");
                System.out.println("6)Write the question to manager");
                System.out.println("0)Exit");
            }
            try {
                option = in.nextInt();
                boolean flag = true;
                while (flag) {
                    if (option == 1) {
                        bankcard.addCard(tin);
                        flag = false;
                    } else if (option == 2) {
                        bankcard.checkCard();
                        flag = false;
                    } else if (option == 3) {
                        bankcard.addMoney(tin);
                        flag = false;
                    } else if (option == 4) {
                        bankcard.transfer_of_money(tin);
                        flag = false;
                    } else if (option == 5) {
                        bankcard.dropcard(tin);
                        flag = false;
                    } else if (option == 6) {
                        userManager.massege_for_manager(tin);
                        flag = false;
                    } else if (option == 0) {
                        System.out.println("Goodbye!");
                        flag = false;
                    } else {
                        System.out.println("You input incorrect option");
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

}
