package Users.Work.WorkUser;

import Conncetion.DB;
import Users.Work.WorkUser.User.UserSystem;

import java.sql.*;
import java.util.Scanner;

public class DBUser {
    Scanner in = new Scanner(System.in);

    public  void log_in(){ //авторизоваться юзеру
        System.out.println("Enter a first name");
        String first_name = in.next();
        System.out.println("Enter a last name");
        String last_name = in.next();
        System.out.println("Enter your taxpayer identification number");
        String TIN = in.next();
        System.out.println("Enter the password");
        String password = in.next();
        System.out.println("Enter your email");
        String email = in.next();
        System.out.println("Enter your phone number");
        String phone_number = in.next();

        Connection con = null;
        try{
            con = DB.getConnection();
            String sql = "SELECT first_name, last_name, tin, password, email, phone_number from users";
            Statement st = con.createStatement();
            ResultSet result = st.executeQuery(sql);
            boolean flag = false;
            while (result.next()){
                String DBfirst_name = result.getString("first_name");
                String DBlast_name = result.getString("last_name");
                String DBTIN = result.getString("tin");
                String DBpassword = result.getString("password");
                String DBemail = result.getString("email");
                String DBphone_number = result.getString("phone_number");
                if(DBfirst_name.equals(first_name) &&
                        DBlast_name.equals(last_name)&&
                        DBTIN.equals(TIN) &&
                        DBpassword.equals(password) &&
                        DBemail.equals(email) &&
                        DBphone_number.equals(phone_number)){
                    flag = true;

                }
            }
            if(flag == true){
                System.out.println("You are logged into your account");
                UserSystem userSystem = new UserSystem();
                userSystem.options(TIN);
            }else{
                System.out.println("This account does not exist");
                boolean fl = true;
                while (fl) {
                    System.out.println("Do you want to re-log in to your account?(yes/no)");
                    String a = in.next();
                    if (a.equals("yes")) {
                        DBUser user = new DBUser();
                        user.log_in();
                        fl = false;
                    } else if (a.equals("no")) {
                        System.out.println("Goodbye");
                        fl = false;
                    } else {
                        System.out.println("You entered the incorrect data");
                    }
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
    //прочекать что бы нельзя было регестрировать два одинаовых юзера
    public void sign_up(){ //регистрация юзера
        System.out.println("Enter a first name");
        String first_name = in.next();
        System.out.println("Enter a last name");
        String last_name = in.next();
        System.out.println("Enter your taxpayer identification number");
        String TIN = in.next();
        System.out.println("Create the password");
        String password = in.next();
        System.out.println("Enter your email");
        String email = in.next();
        System.out.println("Enter your phone number");
        String phone_number = in.next();
        System.out.println("Enter a city where you live");
        String city = in.next();
        Connection con = null;
        try{
            con = DB.getConnection();

            String sql = "SELECT tin, phone_number from users";
            Statement st = con.createStatement();
            ResultSet result = st.executeQuery(sql);
            boolean flag = true;
            while (result.next()){
                String DBTIN = result.getString("tin");
                String DBphone_number = result.getString("phone_number");
                if(     DBTIN.equals(TIN) ||
                        DBphone_number.equals(phone_number)){
                    flag = false;
                }
            }

            if(flag == true) {
                String newsql = "INSERT INTO users(first_name, last_name, tin, password, email,phone_number, city) " +
                        "VALUES(?,?,?,?,?,?, ?)";
                PreparedStatement addUser = con.prepareStatement(newsql);
                addUser.setString(1, first_name);
                addUser.setString(2, last_name);
                addUser.setString(3, TIN);
                addUser.setString(4, password);
                addUser.setString(5, email);
                addUser.setString(6, phone_number);
                addUser.setString(7, city);
                addUser.executeUpdate();
                System.out.println("Your account is registered");
                boolean flags = true;
                while (flags) {
                    System.out.println();
                    System.out.println("Do you want to log in to your account?(yes/no)");
                    String logIn = in.next();
                    if (logIn.equals("yes")) {
                        DBUser user = new DBUser();
                        user.log_in();
                        flags = false;
                    } else if (logIn.equals("no")) {
                        System.out.println("See you soon");
                        //выход из системы
                        flags = false;
                    } else {
                        System.out.println("You entered the incorrect data");
                    }
                }
            }else {
                System.out.println("This account exist");
                boolean flags = true;
                while (flags) {
                    System.out.println();
                    System.out.println("Do you want to log in to your account?(yes/no)");
                    String logIn = in.next();
                    if (logIn.equals("yes")) {
                        DBUser user = new DBUser();
                        user.log_in();
                        flags = false;
                    } else if (logIn.equals("no")) {
                        System.out.println("See you soon");
                        //выход из системы
                        flags = false;
                    } else {
                        System.out.println("You entered the incorrect data");
                    }
                }

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}
