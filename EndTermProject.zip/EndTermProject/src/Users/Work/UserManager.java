package Users.Work;

import Conncetion.DB;
import Users.Work.WorkUser.User.BankCard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class UserManager {
    Scanner in = new Scanner(System.in);
    Random random = new Random();

    public void massege_for_manager(String tin){
        System.out.println("Enter your question");


        Connection con = null;
        try {
            con = DB.getConnection();

            String text = in.nextLine();
            int user_id = BankCard.finduserID(tin);

            ArrayList<Integer> manager_id = new ArrayList();
            String sql = "SELECT manager_id FROM managers";
            Statement st = con.createStatement();
            ResultSet resultSet = st.executeQuery(sql);
            while (resultSet.next()){
                manager_id.add(resultSet.getInt("manager_id"));
            }

            String newsql = "INSERT INTO question(user_id, manager_id, question) VALUES(?,?,?)";
            PreparedStatement prepS = con.prepareStatement(newsql);
            prepS.setInt(1, user_id);
            prepS.setInt(2, manager_id.get(random.nextInt(manager_id.size())));
            prepS.setString(3, text);
            prepS.executeUpdate();
            System.out.println("Your question was sent to manager");
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    public void dropaccount(String tin){
        System.out.println("Are you sure you want to delete your account completely?(yes/no)");
        boolean flag = true;

        while (flag){
            String yesNo  = in.next();
            if(yesNo.equals("yes")){
                System.out.println("Enter the reason for deleting your account, to improve our bank:  ");
                in.nextLine();
                String reasons = in.nextLine();
                Connection con = null;
                try {
                    con = DB.getConnection();
                    ArrayList<Integer> manager_id = new ArrayList();
                    String sql = "SELECT manager_id FROM managers";
                    Statement st = con.createStatement();
                    ResultSet resultSet = st.executeQuery(sql);
                    while (resultSet.next()){
                        manager_id.add(resultSet.getInt("manager_id"));
                    }

                    int user_id = BankCard.finduserID(tin);



                    String newsql = "INSERT INTO dropcard(user_id,manager_id,reason) VALUES(?,?,?)";
                    PreparedStatement prS = con.prepareStatement(newsql);
                    prS.setInt(1, user_id);
                    prS.setInt(2, manager_id.get(random.nextInt(manager_id.size())));
                    prS.setString(3,reasons);
                    prS.executeUpdate();
                    System.out.println("The request was sent for approval to the manager");


                } catch (Exception e) {
                    e.printStackTrace();
                }

                flag = false;


            }else if(yesNo.equals("no")){
                System.out.println("Good solution");
                flag = false;

            }else{
            }
        }



    }

}
