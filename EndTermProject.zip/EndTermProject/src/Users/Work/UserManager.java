package Users.Work;

import Conncetion.DB;
import Users.Work.WorkUser.User.BankCard;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class UserManager {
    Scanner in = new Scanner(System.in);
    Random random = new Random();

    public void massege_for_manager(String tin){
        System.out.println("Enter your question");


        Connection con = null;
        try {
            con = DB.getConnection();

            String text = in.nextLine();
            int user_id = BankCard.finduserID(tin);

            ArrayList<Integer> manager_id = new ArrayList();
            String sql = "SELECT manager_id FROM managers";
            Statement st = con.createStatement();
            ResultSet resultSet = st.executeQuery(sql);
            while (resultSet.next()){
                manager_id.add(resultSet.getInt("manager_id"));
            }

            String newsql = "INSERT INTO question(user_id, manager_id, question) VALUES(?,?,?)";
            PreparedStatement prepS = con.prepareStatement(newsql);
            prepS.setInt(1, user_id);
            prepS.setInt(2, manager_id.get(random.nextInt(manager_id.size())));
            prepS.setString(3, text);
            prepS.executeUpdate();
            System.out.println("Your question was sent to manager");
        } catch (Exception e) {
            e.printStackTrace();
        }


    }

}
