package Users.Work.WorkManager.ManagerSystem;

public class Management {
    //нужно дописать
}
