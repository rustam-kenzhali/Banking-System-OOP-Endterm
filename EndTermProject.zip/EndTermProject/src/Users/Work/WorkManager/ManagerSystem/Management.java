package Users.Work.WorkManager.ManagerSystem;

import Conncetion.DB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Scanner;

public class Management {
    Scanner in = new Scanner(System.in);
    public void dropUserAccount(String manager_tin){

        Connection con = null;
        try {
            con = DB.getConnection();

            String newsql = "SELECT * FROM users INNER JOIN dropcard d on Users.user_id = d.user_id";
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(newsql);
            rs.next();
            int user_id = rs.getInt("user_id");
            String first_name = rs.getString("first_name");
            String last_name = rs.getString("last_name");
            String user_tin = rs.getString("tin");

            String sql = "SELECT * FROM dropcard WHERE user_id = ?";
            PreparedStatement prS = con.prepareStatement(sql);
            prS.setInt(1, user_id);
            ResultSet resultSet = prS.executeQuery();
            resultSet.next();
            String reason = resultSet.getString("reason");

            System.out.println("This user want delete your account: " + first_name + " " + last_name + " " + user_tin);
            System.out.println("Reason: " + reason);

            boolean flag = true;
            while (flag){
                System.out.println("Do you want delete this account?(yes/no)");
                String yesNo = in.next();
                if(yesNo.equals("yes")){
                    String dropAccount = "DELETE FROM dropcard WHERE user_id = ?";
                    PreparedStatement preparedStatement = con.prepareStatement(dropAccount);
                    preparedStatement.setInt(1,user_id);
                    preparedStatement.executeUpdate();

                    dropAccount = "DELETE FROM usercard WHERE user_id = ?";
                    preparedStatement = con.prepareStatement(dropAccount);
                    preparedStatement.setInt(1,user_id);
                    preparedStatement.executeUpdate();

                    dropAccount = "DELETE FROM question WHERE user_id = ?";
                    preparedStatement = con.prepareStatement(dropAccount);
                    preparedStatement.setInt(1,user_id);
                    preparedStatement.executeUpdate();

                    dropAccount = "DELETE FROM users WHERE user_id = ?";
                    preparedStatement = con.prepareStatement(dropAccount);
                    preparedStatement.setInt(1,user_id);
                    preparedStatement.executeUpdate();

                    System.out.println("This account was deleted");

                    flag = false;
                }else if(yesNo.equals("no")){
                    String dropAccount = "DELETE FROM dropcard WHERE user_id = ?";
                    PreparedStatement preparedStatement = con.prepareStatement(dropAccount);
                    preparedStatement.setInt(1,user_id);
                    preparedStatement.executeUpdate();
                    System.out.println("OK, this account will not be deleted");
                    flag = false;
                }else {
                    System.out.println("You entered incorrect word");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    public void checkQuestion(String tin){
        System.out.println("Questions from users: ");

        Connection con = null;
        try {
            con = DB.getConnection();
            String newsql = "SELECT * FROM question INNER JOIN managers ON question.manager_id = managers.manager_id WHERE managers.tin = ?";
            PreparedStatement prS = con.prepareStatement(newsql);
            prS.setString(1,tin);
            prS.execute();
            ResultSet result = prS.executeQuery();
            for(int i = 1; result.next(); i++){
                int user_id = result.getInt("user_id");
                String questions = result.getString("question");
                System.out.println(i + ") " + "user id: " + user_id + " | " + questions);
                if(i == 6){
                    break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
