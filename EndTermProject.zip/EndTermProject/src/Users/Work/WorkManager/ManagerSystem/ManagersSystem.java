package Users.Work.WorkManager.ManagerSystem;


import Users.Work.WorkManager.DBManager;

import java.util.Scanner;

public class ManagersSystem {
    Scanner in = new Scanner(System.in);

    public void options(String tin) {
        System.out.println(tin);
        Management management = new Management();
        if (tin.equals("030407")) {
            System.out.println('\n' + "Select an option");
            System.out.println("1)Drop user account");
            System.out.println("2)Check questions");
            System.out.println("3)Add managers");

            System.out.println("0)Exit");
            boolean f = false;

            int option = 111;
            while (option > 0) {
                if (f == true) {
                    System.out.println();
                    System.out.println("Select an option");
                    System.out.println("1)Drop user account");
                    System.out.println("2)Check questions");
                    System.out.println("3)Add managers");

                    System.out.println("0)Exit");
                }
                option = in.nextInt();
                boolean flag = true;
                while (flag) {
                    if (option == 1) {
                        management.dropUserAccount(tin);
                        flag = false;
                    } else if (option == 2) {
                        management.checkQuestion(tin);
                        flag = false;
                    } else if (option == 3) {
                        DBManager addManager = new DBManager();
                        addManager.newManager();
                        flag = false;
                    } else if (option == 0) {
                        System.out.println("Goodbye!");
                        flag = false;
                    } else {
                        System.out.println("You input incorrect option");
                    }
                }
                f = true;
            }
        } else {
            System.out.println('\n' + "Select an option");
            System.out.println("1)Drop user account");
            System.out.println("2)Check questions");

            System.out.println("0)Exit");
            boolean f = false;

            int option = 111;
            while (option > 0) {
                if (f == true) {
                    System.out.println();
                    System.out.println("Select an option");
                    System.out.println("1)Drop user account");
                    System.out.println("2)Check questions");

                    System.out.println("0)Exit");
                }
                option = in.nextInt();
                boolean flag = true;
                while (flag) {
                    if (option == 1) {
                        management.dropUserAccount(tin);
                        flag = false;
                    } else if (option == 2) {
                        management.checkQuestion(tin);
                        flag = false;
                    } else if (option == 0) {
                        System.out.println("Goodbye!");
                        flag = false;
                    } else {
                        System.out.println("You input incorrect option");
                    }
                }
                f = true;

            }
        }

    }
}
