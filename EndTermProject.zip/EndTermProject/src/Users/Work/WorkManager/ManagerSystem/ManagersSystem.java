package Users.Work.WorkManager.ManagerSystem;


import java.util.Scanner;

public class ManagersSystem {
    Scanner in = new Scanner(System.in);

    public void options() {
        Management management = new Management();
        System.out.println('\n' + "Select an option");
        System.out.println("1)Drop user account");
        System.out.println("2)Check questions");
        System.out.println("3)Add managers");

        System.out.println("0)Exit");
        boolean f = false;

        int option = 111;
        while (option > 0) {
            if(f == true){
                System.out.println();
                System.out.println("Select an option");
                System.out.println("1)");
                System.out.println("2)");
                System.out.println("3)");

                System.out.println("0)Exit");
            }
            option = in.nextInt();
            boolean flag = true;
            while (flag) {
                if (option == 1) {

                    flag = false;
                }else if(option == 2) {

                    flag = false;
                }else if(option == 3) {

                    flag = false;
                }else if(option == 0){
                    System.out.println("Goodbye!");
                    flag = false;
                }
                else {
                    System.out.println("You input incorrect option");
                }
            }
            f = true;
        }
    }

}
