package Users.Work.WorkManager;

import Conncetion.DB;
import Users.Work.WorkManager.ManagerSystem.ManagersSystem;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DBManager {
    Scanner in = new Scanner(System.in);

    public void newManager(){
          /*
    tin           VARCHAR(13)  NOT NULL,
    first_name    VARCHAR(25)   NOT NULL,
    last_name     VARCHAR(25)   NOT NULL,
    login         VARCHAR(25)  NOT NULL,
    password     VARCHAR(25)  NOT NULL*/


        /*System.out.println("Enter your taxpayer identification number");
        String TIN = in.next();

        System.out.println("Enter a first name");
        String first_name = in.next();

        System.out.println("Enter a last name");
        String last_name = in.next();

        System.out.println("Create your login");
        String login = in.next();

        System.out.println("Enter the password");
        String password = in.next();

        Connection con = null;
        try{
            con = DB.getConnection();
            String sql = "INSERT INTO users(tin, first_name, last_name,login, password) " +
                    "VALUES(?,?,?,?,?)";
            PreparedStatement addUser = con.prepareStatement(sql);
            addUser.setString(1, TIN);
            addUser.setString(2, first_name);
            addUser.setString(3, last_name);
            addUser.setString(4, login);
            addUser.setString(5, password);
            addUser.executeUpdate();

            System.out.println("Your account is registered");
            boolean flag = true;
            while (flag) {
                System.out.println();
                System.out.println("Do you want to log in to your account?(yes/no)");
                String logIn = in.next();
                if (logIn.equals("yes")) {
                    DBUser user = new DBUser();
                    user.log_in();
                    flag = false;
                } else if (logIn.equals("no")) {
                    System.out.println("See you soon");
                    //выход из системы
                    flag = false;
                } else {
                    System.out.println("You entered the incorrect data");
                }
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }*/

    }//проверить работает ли авторизация менеджера
    //добавить менеджера через консоль
    //сделать кнопку вопросы у юзера


    public void log_in(){
        //авторизоваться юзеру
        System.out.println("Enter your taxpayer identification number");
        String TIN = in.next();
        System.out.println("Enter a first name");

        String first_name = in.next();
        System.out.println("Enter a last name");
        String last_name = in.next();

        System.out.println("Enter your login");
        String login = in.next();

        System.out.println("Enter the password");
        String password = in.next();


        Connection con = null;
        try{
            con = DB.getConnection();
            String sql = "SELECT tin, first_name, last_name, login, password from managers";
            Statement st = con.createStatement();
            ResultSet result = st.executeQuery(sql);
            boolean flag = false;
            while (result.next()){
                String DBTIN = result.getString("tin");
                String DBfirst_name = result.getString("first_name");
                String DBlast_name = result.getString("last_name");
                String DBlogin = result.getString("login");
                String DBpassword = result.getString("password");

                if(DBfirst_name.equals(first_name) &&
                        DBlast_name.equals(last_name)&&
                        DBTIN.equals(TIN) &&
                        DBlogin.equals(login) &&
                        DBpassword.equals(password)){
                    flag = true;
                }
            }
            if(flag == true){
                System.out.println("Welcome " + first_name + " " + last_name );
                ManagersSystem managersSystem = new ManagersSystem();
                managersSystem.options();
            }else{
                System.out.println("This account does not exist");
                boolean fl = true;
                while (fl) {
                    System.out.println("Do you want to re-log in to your account?(yes/no)");
                    String a = in.next();
                    if (a.equals("yes")) {
                        DBManager user = new DBManager();
                        user.log_in();
                        fl = false;
                    } else if (a.equals("no")) {
                        System.out.println("Goodbye");
                        fl = false;
                    } else {
                        System.out.println("You entered the incorrect data");
                    }
                }
            }

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }


}
